#include "ofApp.h"
#include <ctime>

//--------------------------------------------------------------

const int vitesseRebond = 7;
const int speed = 7;

int t;
int rebond;

ofFbo fbo;

//
void ofApp::setup()
{
    cam.init(ofGetWidth(),ofGetHeight());
    init = true;


    fbo.allocate( ofGetWidth(), ofGetHeight() );

    ofBackground(0,0,0);
	ofEnableDepthTest();
	ofEnableNormalizedTexCoords();
    ofEnableAntiAliasing();
    ofDisableArbTex();

	ofTrueTypeFont::setGlobalDpi(72);
    verdana.loadFont("verdana.ttf", 18, true, true, true);
	verdana.setLineHeight(18.0f);
	verdana.setLetterSpacing(1.037);

	// Create cubes and their materials
    Material* sand = new Material("sand.png");
    materials.push_back(sand);
    Material* stonebrick = new Material("stonebrick.png");
    materials.push_back(stonebrick);

    Material* stonebrick_mossy = new Material("stonebrick_mossy.png");
    materials.push_back(stonebrick_mossy);

    srand(time(NULL));

    Cube* c;
    for (int i=0; i < 2; i++) {
        for (int j=-10; j < 10; j++) {
            for (int k=-10; k < 10; k++) {
                if (i==1){
                    c = new Cube(sand);
                }else{

                    if(rand()%2==0)
                      c = new Cube(stonebrick);
                    else
                      c = new Cube(stonebrick_mossy);
                }
                c->move(j, i+1, k);
                cubes.push_back(c);
            }
        }
    }




    Material* tnt = new Material("tnt.png");
    materials.push_back(tnt);


    //test

    Material* stone = new Material("stone.png");
    materials.push_back(stone);

    c= new Cube(stonebrick_mossy);
    c->move(0,0,4);
    cubes.push_back(c);

    c= new Cube(stone);
    c->move(0,0,2);
    cubes.push_back(c);

    c= new Cube(tnt);
    c->move(0,0,6);
    cubes.push_back(c);

    c= new Cube(stonebrick);
    c->move(2,0,4);
    cubes.push_back(c);

    c= new Cube(sand);
    c->move(-2,0,4);
    cubes.push_back(c);
    //test



    c = new Cube(tnt);
    c->move(2, 0, -1);
    cubes.push_back(c);

    t = 0;
    rebond = 1;

}

//--------------------------------------------------------------
void ofApp::exit()
{
    for (unsigned int i=0; i<cubes.size(); i++) {
        delete cubes[i];
    }
    for (unsigned int i=0; i<materials.size(); i++) {
        delete materials[i];
    }
}

//--------------------------------------------------------------
void ofApp::update()
{
    // Constrain mouse cursor inside window
    if(init){
        moveMouse(ofGetWidth()/2, ofGetHeight()/2);
        init = false;
    }else{
        int x = ofGetMouseX();
        int y = ofGetMouseY();
        if(x >= ofGetWindowWidth()-1)
            moveMouse(1,y);
        if(x <= 0)
            moveMouse(ofGetWindowWidth()-2,y);
        if(y <= 0)
            moveMouse(x,ofGetHeight()-2);
        if(y >= ofGetHeight()-1)
            moveMouse(x,1);
    }

    Cube* c;
    c=cubes.back();

    if(t%vitesseRebond==0)
    {
      rebond=rebond*-1;
      c->move(0,rebond,0);
    }


    t++;



}

//--------------------------------------------------------------
void ofApp::draw()
{
    //fbo.begin();

    ofPushMatrix();
    cam.applyMatrix();
    drawAxes();

    ofPushMatrix();
    ofScale(100,100,100);

    for (unsigned int i=0; i<cubes.size(); i++) {
        cubes[i]->draw();
    }

    ofPopMatrix();
    ofPopMatrix();

    cam.drawAim();

    //fbo.end();

    /*ofPushMatrix();
    cam.applyMatrix();
    drawAxes();

    ofPushMatrix();
    ofScale(100,100,100);

    for (unsigned int i=0; i<cubes.size(); i++) {
        cubes[i]->draw();
    }

    ofPopMatrix();
    ofPopMatrix();

    cam.drawAim();*/

}

//--------------------------------------------------------------
void ofApp::drawAxes()
{
    ofPushMatrix();
    ofSetLineWidth(2);
    ofSetColor(255, 0, 0);
    ofLine(0, 0, 0, 20, 0, 0);
    verdana.drawStringAsShapes("x", 25, 0);
    ofSetColor(0, 255, 0);
    ofLine(0, 0, 0, 0, 20, 0);
    verdana.drawStringAsShapes("y", 5, 25);
    ofSetColor(0, 0, 255);
    ofLine(0, 0, 0, 0, 0, 20);
    ofTranslate(0,0,22);
    verdana.drawStringAsShapes("z", -5, -5);
    ofPopMatrix();
}

//--------------------------------------------------------------
void ofApp::moveMouse(int x, int y)
{
#if defined(__APPLE__)
    CGWarpMouseCursorPosition(CGPointMake(ofGetWindowPositionX()+x,ofGetWindowPositionY()+y));
#elif defined(_WIN32)
    SetCursorPos(x,y); // not tested
#else // xlib
    Display *display = XOpenDisplay(0);
    Window window;
    int state;
    XGetInputFocus(display,&window,&state);
    XWarpPointer(display, None, window, 0, 0, 0, 0, x, y);
    XCloseDisplay(display);
#endif
    cam.mousePressed(x, y);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == 'f')
        ofToggleFullscreen();
    if(key == 'z')
          cam.update(0,speed,false,true,false);
    if(key == 's')
          cam.update(0,-speed,false,true,false);
    if(key == 'q')
          cam.update(speed,0,false,true,false);
    if(key == 'd')
          cam.update(-speed,0,false,true,false);
    if(key == 'g')
         {
          cam.update(0,0,false,false,true);
          //std::cout << "test" << std::endl ;
         }
    if(key == 'h')
         {
          cam.update(1,0,false,false,true);
          //std::cout << "test" << std::endl ;
         }

    if(key == 'j')
         {
          cam.update(2,0,false,false,true);
          //std::cout << "test" << std::endl ;
         }


}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    //cam.update(x, y,false , false, true);
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    if(button==0)
        cam.update(x, y, true, false, false);
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if(button==0 && x>0 && y>0)
        {
          cam.mousePressed(x, y);
          fbo.draw(x,y);
        }

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    cam.init(ofGetWidth(),ofGetHeight());
}
