#include "Camera.h"
#include "ofMain.h"
int axeY=0;
ofVec3f F(0,0,400);
ofVec3f Up=F ;
float tx=0;
float tz=0;
float tmp=0;

ofVec3f eye(0,0,400);
ofVec3f target;


Camera::Camera()
{
}

Camera::~Camera()
{
}

void Camera::init(int windowWidth, int windowHeight)
{
    width = windowWidth;
    height = windowHeight;
    aim_dist = 400;
    rotX = 0;
    rotY = 0;
    lastX = width/2;
    lastY = height/2;
    axeX = 0;
    axeZ = -aim_dist;

}


 void Camera::applyMatrix()
 {
    ofLoadIdentityMatrix();
    //modif
    ofTranslate(axeX ,axeY , axeZ);

    //F=ofVec3f(axeX,axeY,axeZ);
   // Up=F;
    //
    ofRotateX(rotX);
    ofRotateY(rotY);
 }

void Camera::update(int x, int y, bool drag, bool translat, bool rot)
{
    if(drag)
    {
      float rateX = 180.0/float(height);
      float rateY = 180.0/float(width);
      float diffX = x - lastX;
      float diffY = lastY - y;
      lastX = x;
      lastY = y;
      rotX += diffY * rateY;
      rotY += diffX * rateX;

    }
    //modif
    if(translat)
    {
      axeX+=x;
      axeZ+=y;
    }

    if(rot)
    {
      if(x==0)
      {

        rotY+=90;
        target=eye.getRotated(rotY, ofVec3f(0, 1, 0));


        cout << target << endl;
      }

      else if (x==1){
        rotY+=90;

        //rotY++;
        tmp=rotY-tmp;


        Up.rotate(tmp,ofVec3f(0,1,0));
        tmp=rotY;
        std::cout << "1) Up (" << Up << ")" << std::endl;

        Up.x+=tx;
        Up.z+=tz;
        std::cout << "2) Up (" << Up << ")" << std::endl;
        axeX+=F.x-Up.x;
        axeZ+=F.z-Up.z;

        tx=-400;
        tz=+400;

        std::cout << "tx =" << tx << "et tz=" << tz << std::endl << std::endl;
      }

      else {
        rotY+=90;

        Up.rotate(rotY,ofVec3f(0,1,0));

      //std::cout << F-Up << std::endl;
      axeX+=  (-400);
      axeZ+=  (-400);
      }
    }




    //modif



}

void Camera::mousePressed(int x, int y)
{
    lastX = x;
    lastY = y;
}

void Camera::drawAim()
{
    ofDisableDepthTest();

    ofPushMatrix();
    ofTranslate(width/2, height/2);
    ofSetLineWidth(4);
    ofSetColor(100, 100, 100);
    ofLine(-10, 0, 10, 0);
    ofLine(0, -10, 0, 10);
    ofPopMatrix();

    ofEnableDepthTest();
}
