#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup()
{
    cam.init(ofGetWidth(),ofGetHeight());
    init = true;

    ofBackground(0,0,0);
	ofEnableDepthTest();
	ofEnableNormalizedTexCoords();
    ofEnableAntiAliasing();
    ofDisableArbTex();

	ofTrueTypeFont::setGlobalDpi(72);
    verdana.loadFont("verdana.ttf", 18, true, true, true);
	verdana.setLineHeight(18.0f);
	verdana.setLetterSpacing(1.037);

	// Create cubes and their materials
    Material* sand = new Material("sand.png");
    materials.push_back(sand);
    Material* stonebrick = new Material("stonebrick.png");
    materials.push_back(stonebrick);
    Cube* c;
    for (int i=0; i < 2; i++) {
        for (int j=-10; j < 10; j++) {
            for (int k=-10; k < 10; k++) {
                if (i==1){
                    c = new Cube(sand);
                }else{
                    c = new Cube(stonebrick);
                }
                c->move(j, i+1, k);
                cubes.push_back(c);
            }
        }
    }

    Material* tnt = new Material("tnt.png");
    materials.push_back(tnt);
    c = new Cube(tnt);
    c->move(2, 0, -1);
    cubes.push_back(c);
}

//--------------------------------------------------------------
void ofApp::exit()
{
    for (unsigned int i=0; i<cubes.size(); i++) {
        delete cubes[i];
    }
    for (unsigned int i=0; i<materials.size(); i++) {
        delete materials[i];
    }
}

//--------------------------------------------------------------
void ofApp::update()
{
    // Constrain mouse cursor inside window
    if(init){
        moveMouse(ofGetWidth()/2, ofGetHeight()/2);
        init = false;
    }else{
        int x = ofGetMouseX();
        int y = ofGetMouseY();
        if(x >= ofGetWindowWidth()-1)
            moveMouse(1,y);
        if(x <= 0)
            moveMouse(ofGetWindowWidth()-2,y);
        if(y <= 0)
            moveMouse(x,ofGetHeight()-2);
        if(y >= ofGetHeight()-1)
            moveMouse(x,1);
    }
}

//--------------------------------------------------------------
void ofApp::draw()
{
    ofPushMatrix();
    cam.applyMatrix();
    drawAxes();

    ofPushMatrix();
    ofScale(100,100,100);

    for (unsigned int i=0; i<cubes.size(); i++) {
        cubes[i]->draw();
    }

    ofPopMatrix();
    ofPopMatrix();

    cam.drawAim();
}

//--------------------------------------------------------------
void ofApp::drawAxes()
{
    ofPushMatrix();
    ofSetLineWidth(2);
    ofSetColor(255, 0, 0);
    ofLine(0, 0, 0, 20, 0, 0);
    verdana.drawStringAsShapes("x", 25, 0);
    ofSetColor(0, 255, 0);
    ofLine(0, 0, 0, 0, 20, 0);
    verdana.drawStringAsShapes("y", 5, 25);
    ofSetColor(0, 0, 255);
    ofLine(0, 0, 0, 0, 0, 20);
    ofTranslate(0,0,22);
    verdana.drawStringAsShapes("z", -5, -5);
    ofPopMatrix();
}

//--------------------------------------------------------------
void ofApp::moveMouse(int x, int y)
{
#if defined(__APPLE__)
    CGWarpMouseCursorPosition(CGPointMake(ofGetWindowPositionX()+x,ofGetWindowPositionY()+y));
#elif defined(_WIN32)
    SetCursorPos(x,y); // not tested
#else // xlib
    Display *display = XOpenDisplay(0);
    Window window;
    int state;
    XGetInputFocus(display,&window,&state);
    XWarpPointer(display, None, window, 0, 0, 0, 0, x, y);
    XCloseDisplay(display);
#endif
    cam.mousePressed(x, y);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == 'f')
        ofToggleFullscreen();
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    if(button==0)
        cam.update(x, y);
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    if(button==0 && x>0 && y>0)
        cam.mousePressed(x, y);
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    cam.init(ofGetWidth(),ofGetHeight());
}
